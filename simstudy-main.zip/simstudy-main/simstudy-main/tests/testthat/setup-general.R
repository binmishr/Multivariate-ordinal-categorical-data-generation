library(hedgehog)
freeze <- names(.GlobalEnv)
